﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using sxlib;
using sxlib.Specialized;

namespace Loading
{
    public partial class Form1 : Form
    {
        [Serializable]
        public class SynBootstrapperData
        {
            public string UiDownload;
            public string UiHash;
            public string InjectorDownload;
            public string InjectorHash;
            public string BootstrapperVersion;
        }

        [Serializable]
        public class SynVerifiedContents<T>
        {
            public T Contents;
            public string Signature;
        }

        private static SynVerifiedContents<SynBootstrapperData> DeserializedData;
        private static string Version;
        private void CenterTitleText()
        {
            Point CenterSize = new Point();
            CenterSize.X = (this.Size.Width / 2) - (label1.Size.Width / 2);
            CenterSize.Y = label1.Location.Y;
            label1.Location = CenterSize;
        }
        private void LibraryAttachEvent(SxLibBase.SynAttachEvents Event, object whatever)
        {
            switch (Event)
            {
                case SxLibBase.SynAttachEvents.CHECKING:
                    label1.Text = $"{Version}  - Authenticating...";
                    //CenterTitleText();
                    break;
                case SxLibBase.SynAttachEvents.INJECTING:
                    label1.Text = $"{Version}  - Authenticating...";
                    //CenterTitleText();
                    break;
                case SxLibBase.SynAttachEvents.CHECKING_WHITELIST:
                    label1.Text = $"{Version}  - Authenticating...";
                    //CenterTitleText();
                    break;
                case SxLibBase.SynAttachEvents.SCANNING:
                    label1.Text = $"{Version}  - Authenticating...";
                    //CenterTitleText();
                    break;
                case SxLibBase.SynAttachEvents.READY:
                    label1.Text = $"{Version}  - Ready!";
                    //CenterTitleText();
                    timer1.Start();
                    break;
                case SxLibBase.SynAttachEvents.FAILED_TO_FIND:
                    label1.Text = $"{Version}  - Failed to find Roblox!";
                    //CenterTitleText();
                    timer1.Start();
                    break;
                case SxLibBase.SynAttachEvents.NOT_RUNNING_LATEST_VER_UPDATING:
                    //label1.Text = $"{Version} (not running latest version! relaunch.)";
                    //CenterTitleText();
                    timer1.Start();
                    break;
                case SxLibBase.SynAttachEvents.NOT_INJECTED:
                    //label1.Text = $"{Version} (not injected! press attach)";
                    //CenterTitleText();
                    timer1.Start();
                    break;
                case SxLibBase.SynAttachEvents.ALREADY_INJECTED:
                    //label1.Text = $"{Version} (already injected!)";
                    //CenterTitleText();
                    timer1.Start();
                    break;
            }
        }
        public SxLibWinForms SynLib;
        private void Populate(string path)
        {
            listBox1.Items.Clear();

            DirectoryInfo dinfo = new DirectoryInfo(Application.StartupPath + path);
            FileInfo[] Files = dinfo.GetFiles("*.txt");
            FileInfo[] Files1 = dinfo.GetFiles("*.lua");
            foreach (FileInfo file in Files)
            {
                listBox1.Items.Add(file.Name);
            }

            foreach (FileInfo file in Files1)
            {
                listBox1.Items.Add(file.Name);
            }
        }
        public Form1()
        {
            InitializeComponent();
            Functions.Lib.AttachEvent += LibraryAttachEvent;
            Populate(@"\scripts\");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Version = "v4.4.9d";
            label1.Text = $"{Version}";
            try
            {
                this.BackgroundImage = Image.FromFile(@"theme\mainui.png");
                fastColoredTextBox1.BackgroundImage = Image.FromFile(@"theme\editor.png");
                pictureBox3.BackgroundImage = Image.FromFile(@"theme\mainlogo.png");
            }
            catch
            {

            }

        }

        private void elementHost1_ChildChanged(object sender, System.Windows.Forms.Integration.ChildChangedEventArgs e)
        {

        }

 

        private void button5_Click(object sender, EventArgs e)
        {
            SH sh = new SH();
            sh.Show();
        }

        private void flatClose1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Functions.Lib.Attach();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Synapse developed by 3dsboy08 and brack4712.");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Functions.Lib.Execute(fastColoredTextBox1.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Functions.OpenFile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string MainText = File.ReadAllText(Functions.OpenFile.FileName);
                    fastColoredTextBox1.Text = MainText;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = $"{Version}";
            timer1.Stop();
        }
    }
}
