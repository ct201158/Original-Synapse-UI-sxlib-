﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sxlib.Specialized;

namespace Loading
{
    public partial class SH : Form
    {
        SxLibBase.SynHubEntry CurrentEntry;
        public SH()
        {
            InitializeComponent();
            Functions.Lib.ScriptHubEvent += LibraryScriptHubEvent;
            Functions.Lib.ScriptHub();
        }
        List<SxLibBase.SynHubEntry> _entries;
        private void LibraryScriptHubEvent(List<SxLibBase.SynHubEntry> Entries)
        {
            foreach (SxLibBase.SynHubEntry entry in Entries)
            {
                listBox1.Items.Add(entry.Name);
            }
            _entries = Entries;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Functions.Lib.ScriptHubMarkAsClosed();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (SxLibBase.SynHubEntry entry in _entries)
            {
                if (CurrentEntry.Name == entry.Name && listBox1.SelectedIndex != -1)
                {
                    entry.Execute();
                }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1)
            {
                return;
            }
            var CurrentIndex = listBox1.SelectedIndex;
            CurrentEntry = _entries[CurrentIndex];
            richTextBox1.Text = CurrentEntry.Description;
            pictureBox2.Load(CurrentEntry.Picture);
        }

        private void SH_Load(object sender, EventArgs e)
        {
            
        }

        private void flatMini1_Click(object sender, EventArgs e)
        {

        }
    }
}
