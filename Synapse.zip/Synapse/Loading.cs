﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Net;
using System.Threading;
using System.Windows.Forms;
using sxlib;
using sxlib.Specialized;
using System.IO;

namespace Loading
{
	public partial class Synapse : Form
	{
		public SxLibWinForms SynLib;
		public Synapse()
		{
			this.InitializeComponent();
			Functions.Lib = SxLib.InitializeWinForms(this, Directory.GetCurrentDirectory());
			Functions.Lib.Load();
			Functions.Lib.LoadEvent += LibraryLoadEvent;
		}
		private void CenterTitleText()
		{
			Point CenterSize = new Point();
			CenterSize.X = (this.Size.Width / 2) - (label1.Size.Width / 2);
			CenterSize.Y = label1.Location.Y;
			label1.Location = CenterSize;
		}
		private void LibraryLoadEvent(SxLibBase.SynLoadEvents Event, object whatever)
		{
			switch (Event)
			{
				case SxLibBase.SynLoadEvents.CHECKING_WL:
					label1.Text = "[Downloading Data...]";
					CenterTitleText();
					progressBar2.Value = 16;
					break;
				case SxLibBase.SynLoadEvents.CHANGING_WL:
					label1.Text = "[Downloading Data...]";
					CenterTitleText();
					progressBar2.Value = 32;
					break;
				case SxLibBase.SynLoadEvents.DOWNLOADING_DATA:
					label1.Text = "[Downloading Data...]";
					CenterTitleText();
					progressBar2.Value = 53;
					break;
				case SxLibBase.SynLoadEvents.CHECKING_DATA:
					label1.Text = "[Preparing...]";
					CenterTitleText();
					progressBar2.Value = 64;
					break;
				case SxLibBase.SynLoadEvents.DOWNLOADING_DLLS:
					label1.Text = "[Preparing...]";
					CenterTitleText();
					progressBar2.Value = 86;
					break;
				case SxLibBase.SynLoadEvents.READY:
					label1.Text = "[Ready!]";
					label1.Refresh();
					CenterTitleText();
					progressBar2.Value = 100;
					Form1 main = new Form1();
					main.Show();
					this.Hide();
					break;
			}
		}
		private void Form1_Load(object sender, EventArgs e)
		{
			//this.timer1.Start();
			//Functions.Lib = SxLib.InitializeWinForms(this, Directory.GetCurrentDirectory());
		}
		private void label1_Click(object sender, EventArgs e)
		{
		}
		private void timer1_Tick(object sender, EventArgs e)
		{
			//Random random = new Random();
			//int num = random.Next(2, 5);
			//this.panel3.Width += num;
			//bool flag = this.panel3.Width >= 140;
			//if (flag)
			//{
			//	this.label1.Hide();
			//	this.label3.Show();
			//}
			//bool flag2 = this.panel3.Width >= 220;
			//if (flag2)
			//{
			//	this.label3.Hide();
			//	this.label4.Show();
			//}
			//bool flag3 = this.panel3.Width >= 340;
			//if (flag3)
			//{
			//	this.timer1.Stop();
			//	base.Opacity = 0.9;
			//	Thread.Sleep(30);
			//	base.Opacity = 0.8;
			//	Thread.Sleep(30);
			//	base.Opacity = 0.7;
			//	Thread.Sleep(30);
			//	base.Opacity = 0.6;
			//	Thread.Sleep(30);
			//	base.Opacity = 0.5;
			//	Thread.Sleep(30);
			//	base.Opacity = 0.4;
			//	Thread.Sleep(30);
			//	base.Opacity = 0.3;
			//	Thread.Sleep(30);
			//	base.Opacity = 0.2;
			//	Thread.Sleep(30);
			//	base.Opacity = 0.1;
			//	Thread.Sleep(30);
			//	base.Opacity = 0.0;
			//	Thread.Sleep(30);
			//	Form1 syn = new Form1();
			//	Functions.Lib.Load();
			//	syn.Show();
			//	this.Hide();
			//	timer1.Stop();
			//}
		}
		private void progressBar1_Click(object sender, EventArgs e)
		{
		}
		private void label4_Click(object sender, EventArgs e)
		{
		}
		private void panel2_Paint(object sender, PaintEventArgs e)
		{
		}
		private void panel3_Paint(object sender, PaintEventArgs e)
		{
		}

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
